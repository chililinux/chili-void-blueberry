
A Bluetooth configuration tool.
Depends on gnome-bluetooth 3.14.